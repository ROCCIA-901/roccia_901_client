class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Common images
  static String imgProfile = '$imagePath/img_profile.svg';

  static String imgArrowLeftBlack900 =
      '$imagePath/img_arrow_left_black_900.svg';

  static String imgArrowdown = '$imagePath/img_arrowdown.svg';

  static String imgMobile = '$imagePath/img_mobile.svg';

  static String imgTelevision = '$imagePath/img_television.svg';

  static String imgSettings = '$imagePath/img_settings.svg';

  static String imgUser = '$imagePath/img_user.svg';

  static String imgSettingsOnprimary = '$imagePath/img_settings_onprimary.svg';

  static String imgUserWhiteA700 = '$imagePath/img_user_white_a700.svg';

  static String imgPlay = '$imagePath/img_play.svg';

  static String imgFavorite = '$imagePath/img_favorite.svg';

  static String imgSettingsPrimary = '$imagePath/img_settings_primary.svg';

  static String imgPinterest = '$imagePath/img_pinterest.svg';

  static String imgNav = '$imagePath/img_nav.svg';

  static String imgNavPrimary = '$imagePath/img_nav_primary.svg';

  static String imgNavPrimary27x27 = '$imagePath/img_nav_primary_27x27.svg';

  static String imgNav27x27 = '$imagePath/img_nav_27x27.svg';

  static String imgGroup6268 = '$imagePath/img_group_6268.svg';

  static String imgUserPrimary = '$imagePath/img_user_primary.svg';

  static String imgCheckmark = '$imagePath/img_checkmark.svg';

  static String imgArrowRight = '$imagePath/img_arrow_right.svg';

  static String imgUserPrimary50x49 = '$imagePath/img_user_primary_50x49.svg';

  static String imgPlayPrimary = '$imagePath/img_play_primary.svg';

  static String imgPlayPrimary49x49 = '$imagePath/img_play_primary_49x49.svg';

  static String imgRewind = '$imagePath/img_rewind.svg';

  static String imgNav1 = '$imagePath/img_nav_1.svg';

  static String imgNav2 = '$imagePath/img_nav_2.svg';

  static String imgClose = '$imagePath/img_close.svg';

  static String imgVectorBlueGray100 =
      '$imagePath/img_vector_blue_gray_100.svg';

  static String imgCloseWhiteA700 = '$imagePath/img_close_white_a700.svg';

  static String imgVectorGray600 = '$imagePath/img_vector_gray_600.svg';

  static String imgProfileGray300 = '$imagePath/img_profile_gray_300.svg';

  static String imgSettingsOnsecondarycontainer =
      '$imagePath/img_settings_onsecondarycontainer.svg';

  static String imgVector = '$imagePath/img_vector.svg';

  static String imgLock = '$imagePath/img_lock.svg';

  static String imgNav3 = '$imagePath/img_nav_3.svg';

  static String imgArrowLeft = '$imagePath/img_arrow_left.svg';

  static String imgSettingsOnprimary58x44 =
      '$imagePath/img_settings_onprimary_58x44.svg';

  static String imgVectorGray500 = '$imagePath/img_vector_gray_500.svg';

  static String imgNav4 = '$imagePath/img_nav_4.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
