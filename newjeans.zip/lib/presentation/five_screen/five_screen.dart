import 'package:flutter/material.dart';
import 'package:newjeans_s_application1/core/app_export.dart';
import 'package:newjeans_s_application1/widgets/custom_elevated_button.dart';
import 'package:newjeans_s_application1/widgets/custom_text_form_field.dart';

class FiveScreen extends StatelessWidget {
  FiveScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController enteremailController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.only(
            left: 24.h,
            top: 120.v,
            right: 24.h,
          ),
          child: Column(
            children: [
              CustomImageView(
                imagePath: ImageConstant.imgProfile,
                height: 55.v,
                width: 49.h,
              ),
              SizedBox(height: 13.v),
              Text(
                "ROCCIA 901",
                style: theme.textTheme.headlineSmall,
              ),
              SizedBox(height: 33.v),
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  "비밀번호 찾기",
                  style: CustomTextStyles.bodySmallArchivoBlackBlack900,
                ),
              ),
              SizedBox(height: 15.v),
              _buildEnterEmailRow(context),
              SizedBox(height: 3.v),
              _buildVerificationCodeConfirmationRow(context),
              SizedBox(height: 15.v),
              _buildChangePasswordButton(context),
              SizedBox(height: 3.v),
              Align(
                alignment: Alignment.centerRight,
                child: Padding(
                  padding: EdgeInsets.only(right: 1.h),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Text(
                        "회원가입",
                        style: CustomTextStyles
                            .bodySmallArchivoBlackBluegray10001_1,
                      ),
                      Padding(
                        padding: EdgeInsets.only(left: 6.h),
                        child: Text(
                          "ㅣ",
                          style: CustomTextStyles
                              .bodySmallArchivoBlackBluegray10001_1,
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(left: 5.h),
                        child: Text(
                          "로그인",
                          style: CustomTextStyles
                              .bodySmallArchivoBlackBluegray10001_1,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 5.v),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildEnteremail(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: 2.v),
      child: CustomTextFormField(
        width: 202.h,
        controller: enteremailController,
        hintText: "이메일을 입력해 주세요.",
        textInputAction: TextInputAction.done,
        borderDecoration: TextFormFieldStyleHelper.outlineBlueGray,
        filled: true,
        fillColor: appTheme.whiteA700,
      ),
    );
  }

  /// Section Widget
  Widget _buildTf(BuildContext context) {
    return CustomElevatedButton(
      width: 97.h,
      text: "인증번호 받기",
      buttonStyle: CustomButtonStyles.fillPrimaryTL6,
      buttonTextStyle: CustomTextStyles.labelLargeRoboto,
    );
  }

  /// Section Widget
  Widget _buildEnterEmailRow(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(right: 1.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          _buildEnteremail(context),
          _buildTf(context),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildTf1(BuildContext context) {
    return CustomElevatedButton(
      width: 97.h,
      text: "인증번호 확인",
      buttonStyle: CustomButtonStyles.fillPrimaryTL6,
      buttonTextStyle: CustomTextStyles.labelLargeRoboto,
    );
  }

  /// Section Widget
  Widget _buildVerificationCodeConfirmationRow(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(right: 1.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Card(
            clipBehavior: Clip.antiAlias,
            elevation: 0,
            margin: EdgeInsets.all(0),
            shape: RoundedRectangleBorder(
              side: BorderSide(
                color: appTheme.blueGray10001,
                width: 1.h,
              ),
              borderRadius: BorderRadiusStyle.roundedBorder6,
            ),
            child: Container(
              height: 38.v,
              width: 202.h,
              padding: EdgeInsets.all(9.h),
              decoration: AppDecoration.outlineBlueGray.copyWith(
                borderRadius: BorderRadiusStyle.roundedBorder6,
              ),
              child: Stack(
                alignment: Alignment.topRight,
                children: [
                  Align(
                    alignment: Alignment.topRight,
                    child: Text(
                      "1:00",
                      style: CustomTextStyles.bodySmallRobotoBluegray10001,
                    ),
                  ),
                  Align(
                    alignment: Alignment.topRight,
                    child: Text(
                      "1:00",
                      style: CustomTextStyles.bodySmallRobotoBluegray10001,
                    ),
                  ),
                ],
              ),
            ),
          ),
          _buildTf1(context),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildChangePasswordButton(BuildContext context) {
    return CustomElevatedButton(
      text: "이메일 인증으로 비밀번호 변경하기",
    );
  }
}
