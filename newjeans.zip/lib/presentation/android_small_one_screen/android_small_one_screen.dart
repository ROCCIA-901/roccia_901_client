import 'package:flutter/material.dart';
import 'package:newjeans_s_application1/core/app_export.dart';

class AndroidSmallOneScreen extends StatelessWidget {
  const AndroidSmallOneScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: SizedBox(
          height: SizeUtils.height,
          width: double.maxFinite,
        ),
      ),
    );
  }
}
