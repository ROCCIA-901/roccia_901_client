import 'package:flutter/material.dart';
import 'package:newjeans_s_application1/core/app_export.dart';
import 'package:newjeans_s_application1/presentation/two3_page/two3_page.dart';
import 'package:newjeans_s_application1/widgets/app_bar/appbar_title.dart';
import 'package:newjeans_s_application1/widgets/app_bar/appbar_trailing_image.dart';
import 'package:newjeans_s_application1/widgets/app_bar/custom_app_bar.dart';
import 'package:newjeans_s_application1/widgets/custom_bottom_bar.dart';

class K37Screen extends StatelessWidget {
  K37Screen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: SizedBox(
          width: double.maxFinite,
          child: Column(
            children: [
              _buildStackColumn(context),
              SizedBox(height: 27.v),
              Expanded(
                child: SingleChildScrollView(
                  child: Padding(
                    padding: EdgeInsets.only(bottom: 5.v),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: EdgeInsets.only(left: 31.h),
                          child: Row(
                            children: [
                              Text(
                                "프로필",
                                style: theme.textTheme.bodySmall,
                              ),
                              CustomImageView(
                                imagePath: ImageConstant.imgVectorGray500,
                                height: 5.adaptSize,
                                width: 5.adaptSize,
                                margin: EdgeInsets.only(
                                  left: 2.h,
                                  top: 5.v,
                                  bottom: 2.v,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 26.v),
                        Padding(
                          padding: EdgeInsets.only(left: 31.h),
                          child: Row(
                            children: [
                              Text(
                                "이름",
                                style: CustomTextStyles.bodySmallRoboto,
                              ),
                              Padding(
                                padding: EdgeInsets.only(left: 56.h),
                                child: Text(
                                  "김동욱",
                                  style:
                                      CustomTextStyles.bodySmallRobotoBlack900,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 9.v),
                        Padding(
                          padding: EdgeInsets.only(left: 31.h),
                          child: Row(
                            children: [
                              Text(
                                "기수",
                                style: CustomTextStyles.bodySmallRoboto,
                              ),
                              Padding(
                                padding: EdgeInsets.only(left: 56.h),
                                child: Text(
                                  "8기",
                                  style:
                                      CustomTextStyles.bodySmallRobotoBlack900,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 8.v),
                        Padding(
                          padding: EdgeInsets.only(left: 31.h),
                          child: Row(
                            children: [
                              Text(
                                "역할",
                                style: CustomTextStyles.bodySmallRoboto,
                              ),
                              Padding(
                                padding: EdgeInsets.only(left: 56.h),
                                child: Text(
                                  "부원",
                                  style:
                                      CustomTextStyles.bodySmallRobotoBlack900,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 9.v),
                        Padding(
                          padding: EdgeInsets.only(left: 31.h),
                          child: Row(
                            children: [
                              Text(
                                "운동 지점",
                                style: CustomTextStyles.bodySmallRoboto,
                              ),
                              Padding(
                                padding: EdgeInsets.only(left: 32.h),
                                child: Text(
                                  "더클라임 연남",
                                  style:
                                      CustomTextStyles.bodySmallRobotoBlack900,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 9.v),
                        Padding(
                          padding: EdgeInsets.only(left: 31.h),
                          child: Row(
                            children: [
                              Text(
                                "난이도",
                                style: CustomTextStyles.bodySmallRoboto,
                              ),
                              Padding(
                                padding: EdgeInsets.only(left: 45.h),
                                child: Text(
                                  "파랑",
                                  style:
                                      CustomTextStyles.bodySmallRobotoBlack900,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 32.v),
                        Divider(),
                        SizedBox(height: 25.v),
                        Padding(
                          padding: EdgeInsets.only(left: 31.h),
                          child: Text(
                            "내 출석",
                            style: theme.textTheme.bodySmall,
                          ),
                        ),
                        SizedBox(height: 26.v),
                        Padding(
                          padding: EdgeInsets.only(left: 31.h),
                          child: _buildZeroOneRow(
                            context,
                            dynamicText: "출석",
                            dynamicText1: "3회",
                          ),
                        ),
                        SizedBox(height: 7.v),
                        Padding(
                          padding: EdgeInsets.only(left: 31.h),
                          child: _buildZeroOneRow(
                            context,
                            dynamicText: "지각",
                            dynamicText1: "0회",
                          ),
                        ),
                        SizedBox(height: 7.v),
                        Padding(
                          padding: EdgeInsets.only(left: 31.h),
                          child: _buildZeroOneRow(
                            context,
                            dynamicText: "결석",
                            dynamicText1: "1회",
                          ),
                        ),
                        SizedBox(height: 32.v),
                        Divider(),
                        SizedBox(height: 27.v),
                        Padding(
                          padding: EdgeInsets.only(left: 31.h),
                          child: Text(
                            "내 기록",
                            style: theme.textTheme.bodySmall,
                          ),
                        ),
                        SizedBox(height: 26.v),
                        Padding(
                          padding: EdgeInsets.only(left: 31.h),
                          child: _buildZeroOneRow(
                            context,
                            dynamicText: "초록",
                            dynamicText1: "3회",
                          ),
                        ),
                        SizedBox(height: 8.v),
                        Padding(
                          padding: EdgeInsets.only(left: 31.h),
                          child: _buildZeroOneRow(
                            context,
                            dynamicText: "파랑",
                            dynamicText1: "0회",
                          ),
                        ),
                        SizedBox(height: 8.v),
                        Padding(
                          padding: EdgeInsets.only(left: 31.h),
                          child: _buildZeroOneRow(
                            context,
                            dynamicText: "빨강",
                            dynamicText1: "1회",
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: _buildBottomBar(context),
      ),
    );
  }

  /// Section Widget
  Widget _buildTenColumn(BuildContext context) {
    return Align(
      alignment: Alignment.bottomCenter,
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 31.h),
        padding: EdgeInsets.symmetric(
          horizontal: 18.h,
          vertical: 22.v,
        ),
        decoration: AppDecoration.outlineBluegray400.copyWith(
          borderRadius: BorderRadiusStyle.roundedBorder6,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(height: 3.v),
            Container(
              width: 221.h,
              margin: EdgeInsets.only(right: 38.h),
              child: Text(
                "안녕하세요,  이번 10기에 새로 들어왔습니다.\n앞으로 잘 부탁드립니다!",
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: CustomTextStyles.bodySmallRobotoBlack900.copyWith(
                  height: 1.67,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildStackColumn(BuildContext context) {
    return SizedBox(
      height: 239.v,
      width: double.maxFinite,
      child: Stack(
        alignment: Alignment.bottomCenter,
        children: [
          Align(
            alignment: Alignment.topCenter,
            child: Container(
              padding: EdgeInsets.symmetric(vertical: 11.v),
              decoration: AppDecoration.outlineBlack,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CustomAppBar(
                    height: 26.v,
                    title: AppbarTitle(
                      text: "마이페이지",
                      margin: EdgeInsets.only(left: 24.h),
                    ),
                    actions: [
                      AppbarTrailingImage(
                        imagePath: ImageConstant.imgArrowLeft,
                        margin: EdgeInsets.only(
                          left: 11.h,
                          right: 11.h,
                          bottom: 12.v,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 15.v),
                  Container(
                    height: 75.adaptSize,
                    width: 75.adaptSize,
                    padding: EdgeInsets.symmetric(
                      horizontal: 15.h,
                      vertical: 7.v,
                    ),
                    decoration: AppDecoration.fillPrimary.copyWith(
                      borderRadius: BorderRadiusStyle.roundedBorder37,
                    ),
                    child: CustomImageView(
                      imagePath: ImageConstant.imgSettingsOnprimary58x44,
                      height: 58.v,
                      width: 44.h,
                      alignment: Alignment.center,
                    ),
                  ),
                  SizedBox(height: 47.v),
                ],
              ),
            ),
          ),
          _buildTenColumn(context),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        Navigator.pushNamed(
            navigatorKey.currentContext!, getCurrentRoute(type));
      },
    );
  }

  /// Common widget
  Widget _buildZeroOneRow(
    BuildContext context, {
    required String dynamicText,
    required String dynamicText1,
  }) {
    return Row(
      children: [
        Padding(
          padding: EdgeInsets.only(bottom: 2.v),
          child: Text(
            dynamicText,
            style: CustomTextStyles.bodySmallRoboto.copyWith(
              color: appTheme.gray500,
            ),
          ),
        ),
        Padding(
          padding: EdgeInsets.only(left: 56.h),
          child: Text(
            dynamicText1,
            style: CustomTextStyles.bodySmallRobotoBlack900.copyWith(
              color: appTheme.black900,
            ),
          ),
        ),
      ],
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.tf:
        return AppRoutes.two3Page;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.two3Page:
        return Two3Page();
      default:
        return DefaultWidget();
    }
  }
}
