import 'package:flutter/material.dart';
import 'package:newjeans_s_application1/core/app_export.dart';
import 'package:newjeans_s_application1/presentation/two3_page/two3_page.dart';
import 'package:newjeans_s_application1/widgets/app_bar/appbar_title.dart';
import 'package:newjeans_s_application1/widgets/app_bar/custom_app_bar.dart';
import 'package:newjeans_s_application1/widgets/custom_bottom_bar.dart';
import 'package:newjeans_s_application1/widgets/custom_elevated_button.dart';

class K31Screen extends StatelessWidget {
  K31Screen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: _buildAppBar(context),
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(vertical: 3.v),
          child: Column(
            children: [
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 73.h),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "내 기록",
                      style: theme.textTheme.bodySmall,
                    ),
                    Text(
                      "랭킹",
                      style: CustomTextStyles.bodySmallBlack900,
                    ),
                  ],
                ),
              ),
              SizedBox(height: 3.v),
              Align(
                alignment: Alignment.centerRight,
                child: SizedBox(
                  width: 180.h,
                  child: Divider(
                    color: theme.colorScheme.primary,
                  ),
                ),
              ),
              SizedBox(height: 30.v),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CustomElevatedButton(
                    height: 20.v,
                    width: 50.h,
                    text: "주간",
                    buttonTextStyle: theme.textTheme.labelMedium!,
                  ),
                  CustomElevatedButton(
                    height: 20.v,
                    width: 50.h,
                    text: "전체",
                    margin: EdgeInsets.only(left: 20.h),
                    buttonStyle: CustomButtonStyles.fillGray,
                    buttonTextStyle: theme.textTheme.labelMedium!,
                  ),
                ],
              ),
              SizedBox(height: 29.v),
              Padding(
                padding: EdgeInsets.only(
                  left: 44.h,
                  right: 49.h,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    CustomImageView(
                      imagePath: ImageConstant.imgVectorGray600,
                      height: 8.v,
                      width: 5.h,
                      margin: EdgeInsets.symmetric(vertical: 3.v),
                    ),
                    Text(
                      "1주차",
                      style: CustomTextStyles.labelLargeGray600,
                    ),
                    CustomImageView(
                      imagePath: ImageConstant.imgVectorGray600,
                      height: 8.v,
                      width: 5.h,
                      margin: EdgeInsets.symmetric(vertical: 3.v),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 15.v),
              Align(
                alignment: Alignment.centerRight,
                child: Padding(
                  padding: EdgeInsets.only(right: 3.h),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      CustomImageView(
                        imagePath: ImageConstant.imgProfileGray300,
                        height: 8.adaptSize,
                        width: 8.adaptSize,
                        margin: EdgeInsets.only(bottom: 1.v),
                      ),
                      Padding(
                        padding: EdgeInsets.only(left: 2.h),
                        child: Text(
                          "랭킹 기준",
                          style: theme.textTheme.labelSmall,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Divider(),
              SizedBox(height: 13.v),
              Align(
                alignment: Alignment.centerRight,
                child: Padding(
                  padding: EdgeInsets.only(
                    left: 88.h,
                    right: 52.h,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Text(
                        "프로필",
                        style: CustomTextStyles.bodySmallGray600,
                      ),
                      Spacer(
                        flex: 69,
                      ),
                      Text(
                        "총점",
                        style: CustomTextStyles.bodySmallGray600,
                      ),
                      Spacer(
                        flex: 30,
                      ),
                      Text(
                        "순위",
                        style: CustomTextStyles.bodySmallGray600,
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 9.v),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 10.h),
                child: _buildUserRow1(
                  context,
                  userImage: ImageConstant.imgUserPrimary,
                  widgetText1: "8기",
                  widgetText2: "파랑",
                  widgetText3: "35점",
                  widgetText4: "1",
                  vectorImage: ImageConstant.imgSettingsOnsecondarycontainer,
                  widgetText5: "김동욱",
                  widgetText6: "더클라임 연남점",
                ),
              ),
              SizedBox(height: 5.v),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 10.h),
                child: _buildUserRow1(
                  context,
                  userImage: ImageConstant.imgUserPrimary50x49,
                  widgetText1: "3기",
                  widgetText2: "파랑",
                  widgetText3: "33점",
                  widgetText4: "2",
                  vectorImage: ImageConstant.imgVector,
                  widgetText5: "박형기",
                  widgetText6: "더클라임 신림점",
                ),
              ),
              SizedBox(height: 5.v),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 10.h),
                child: _buildUserRow1(
                  context,
                  userImage: ImageConstant.imgPlayPrimary,
                  widgetText1: "8기",
                  widgetText2: "초록",
                  widgetText3: "32점",
                  widgetText4: "3",
                  vectorImage: ImageConstant.imgLock,
                  widgetText5: "권순형",
                  widgetText6: "더클라임 양재점",
                ),
              ),
              SizedBox(height: 5.v),
              _buildPlayRow1(context),
              SizedBox(height: 5.v),
            ],
          ),
        ),
        bottomNavigationBar: _buildBottomBar(context),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      title: AppbarTitle(
        text: "기록",
        margin: EdgeInsets.only(left: 24.h),
      ),
    );
  }

  /// Section Widget
  Widget _buildPlayRow1(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 10.h),
      padding: EdgeInsets.symmetric(
        horizontal: 13.h,
        vertical: 4.v,
      ),
      decoration: AppDecoration.outlineGray300.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder6,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.max,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgPlayPrimary49x49,
            height: 49.adaptSize,
            width: 49.adaptSize,
            margin: EdgeInsets.only(top: 1.v),
          ),
          Padding(
            padding: EdgeInsets.only(
              left: 10.h,
              top: 6.v,
              bottom: 6.v,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildWidget(
                  context,
                  userName: "강상우",
                  storeName: "더클라임 연남점",
                ),
                SizedBox(height: 6.v),
                Row(
                  children: [
                    Container(
                      width: 30.h,
                      padding: EdgeInsets.symmetric(
                        horizontal: 5.h,
                        vertical: 2.v,
                      ),
                      decoration: AppDecoration.outlineGray300.copyWith(
                        borderRadius: BorderRadiusStyle.roundedBorder6,
                      ),
                      child: Text(
                        "10기",
                        style: CustomTextStyles.bodySmallRobotoGray6008,
                      ),
                    ),
                    Container(
                      width: 35.h,
                      margin: EdgeInsets.only(left: 3.h),
                      padding: EdgeInsets.symmetric(
                        horizontal: 10.h,
                        vertical: 3.v,
                      ),
                      decoration: AppDecoration.outlineGray300.copyWith(
                        borderRadius: BorderRadiusStyle.roundedBorder6,
                      ),
                      child: Text(
                        "빨랑",
                        style: CustomTextStyles.bodySmallRobotoGray6008,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Spacer(
            flex: 45,
          ),
          Padding(
            padding: EdgeInsets.only(
              top: 18.v,
              bottom: 19.v,
            ),
            child: Text(
              "29점",
              style: CustomTextStyles.bodySmallRobotoGray600,
            ),
          ),
          Spacer(
            flex: 54,
          ),
          Padding(
            padding: EdgeInsets.only(
              top: 18.v,
              right: 10.h,
              bottom: 19.v,
            ),
            child: Text(
              "4",
              style: CustomTextStyles.bodySmallRobotoBlack900_1,
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        Navigator.pushNamed(
            navigatorKey.currentContext!, getCurrentRoute(type));
      },
    );
  }

  /// Common widget
  Widget _buildUserRow1(
    BuildContext context, {
    required String userImage,
    required String widgetText1,
    required String widgetText2,
    required String widgetText3,
    required String widgetText4,
    required String vectorImage,
    required String widgetText5,
    required String widgetText6,
  }) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 13.h,
        vertical: 3.v,
      ),
      decoration: AppDecoration.outlineGray300.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder6,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.max,
        children: [
          CustomImageView(
            imagePath: userImage,
            height: 50.v,
            width: 49.h,
            margin: EdgeInsets.only(top: 2.v),
          ),
          Container(
            height: 38.v,
            width: 232.h,
            margin: EdgeInsets.only(
              left: 10.h,
              top: 6.v,
              bottom: 6.v,
            ),
            child: Stack(
              alignment: Alignment.topLeft,
              children: [
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Container(
                    width: 232.h,
                    margin: EdgeInsets.only(top: 12.v),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 30.h,
                          margin: EdgeInsets.only(top: 9.v),
                          padding: EdgeInsets.symmetric(
                            horizontal: 9.h,
                            vertical: 2.v,
                          ),
                          decoration: AppDecoration.outlineGray300.copyWith(
                            borderRadius: BorderRadiusStyle.roundedBorder6,
                          ),
                          child: Text(
                            widgetText1,
                            style: CustomTextStyles.bodySmallRobotoGray6008
                                .copyWith(
                              color: appTheme.gray600,
                            ),
                          ),
                        ),
                        Container(
                          width: 35.h,
                          margin: EdgeInsets.only(
                            left: 3.h,
                            top: 9.v,
                          ),
                          padding: EdgeInsets.symmetric(
                            horizontal: 10.h,
                            vertical: 2.v,
                          ),
                          decoration: AppDecoration.outlineGray300.copyWith(
                            borderRadius: BorderRadiusStyle.roundedBorder6,
                          ),
                          child: Text(
                            widgetText2,
                            style: CustomTextStyles.bodySmallRobotoGray6008
                                .copyWith(
                              color: appTheme.gray600,
                            ),
                          ),
                        ),
                        Spacer(
                          flex: 57,
                        ),
                        Padding(
                          padding: EdgeInsets.only(bottom: 13.v),
                          child: Text(
                            widgetText3,
                            style: CustomTextStyles.bodySmallRobotoGray600
                                .copyWith(
                              color: appTheme.gray600,
                            ),
                          ),
                        ),
                        Spacer(
                          flex: 42,
                        ),
                        Padding(
                          padding: EdgeInsets.only(bottom: 13.v),
                          child: Text(
                            widgetText4,
                            style: CustomTextStyles.bodySmallRobotoBlack900_1
                                .copyWith(
                              color: appTheme.black900,
                            ),
                          ),
                        ),
                        CustomImageView(
                          imagePath: vectorImage,
                          height: 7.v,
                          width: 8.h,
                          margin: EdgeInsets.only(
                            left: 4.h,
                            top: 2.v,
                            bottom: 16.v,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Align(
                  alignment: Alignment.topLeft,
                  child: Row(
                    children: [
                      Text(
                        widgetText5,
                        style:
                            CustomTextStyles.bodySmallRobotoBlack900.copyWith(
                          color: appTheme.black900,
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                          left: 10.h,
                          top: 5.v,
                        ),
                        child: Text(
                          widgetText6,
                          style: CustomTextStyles.bodySmallRobotoBluegray400
                              .copyWith(
                            color: appTheme.blueGray400,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// Common widget
  Widget _buildWidget(
    BuildContext context, {
    required String userName,
    required String storeName,
  }) {
    return SizedBox(
      width: 96.h,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            userName,
            style: CustomTextStyles.bodySmallRobotoBlack900.copyWith(
              color: appTheme.black900,
            ),
          ),
          Padding(
            padding: EdgeInsets.only(top: 4.v),
            child: Text(
              storeName,
              style: CustomTextStyles.bodySmallRobotoBluegray400.copyWith(
                color: appTheme.blueGray400,
              ),
            ),
          ),
        ],
      ),
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.tf:
        return AppRoutes.two3Page;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.two3Page:
        return Two3Page();
      default:
        return DefaultWidget();
    }
  }
}
