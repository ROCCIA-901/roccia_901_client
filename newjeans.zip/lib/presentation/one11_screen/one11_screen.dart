import 'package:flutter/material.dart';
import 'package:newjeans_s_application1/core/app_export.dart';
import 'package:newjeans_s_application1/presentation/two3_page/two3_page.dart';
import 'package:newjeans_s_application1/widgets/app_bar/appbar_title.dart';
import 'package:newjeans_s_application1/widgets/app_bar/custom_app_bar.dart';
import 'package:newjeans_s_application1/widgets/custom_bottom_bar.dart';

class One11Screen extends StatelessWidget {
  One11Screen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: _buildAppBar(context),
        body: SizedBox(
          width: double.maxFinite,
          child: Column(
            children: [
              Spacer(
                flex: 53,
              ),
              Text(
                "대회 기간에 사용하실 수 있습니다.",
                style: CustomTextStyles.bodySmall12,
              ),
              Spacer(
                flex: 46,
              ),
            ],
          ),
        ),
        bottomNavigationBar: _buildBottomBar(context),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      title: AppbarTitle(
        text: "대회",
        margin: EdgeInsets.only(left: 24.h),
      ),
    );
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        Navigator.pushNamed(
            navigatorKey.currentContext!, getCurrentRoute(type));
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.tf:
        return AppRoutes.two3Page;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.two3Page:
        return Two3Page();
      default:
        return DefaultWidget();
    }
  }
}
