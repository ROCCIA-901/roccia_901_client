import 'package:calendar_date_picker2/calendar_date_picker2.dart';
import 'package:flutter/material.dart';
import 'package:newjeans_s_application1/core/app_export.dart';
import 'package:newjeans_s_application1/presentation/two3_page/two3_page.dart';
import 'package:newjeans_s_application1/widgets/app_bar/appbar_title.dart';
import 'package:newjeans_s_application1/widgets/app_bar/custom_app_bar.dart';
import 'package:newjeans_s_application1/widgets/custom_bottom_bar.dart';
import 'package:newjeans_s_application1/widgets/custom_elevated_button.dart';

class One6Screen extends StatelessWidget {
  One6Screen({Key? key})
      : super(
          key: key,
        );

  List<DateTime?> selectedDatesFromCalendar1 = [];

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: _buildAppBar(context),
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(vertical: 3.v),
          child: Column(
            children: [
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 73.h),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "내 기록",
                      style: CustomTextStyles.bodySmallBlack900,
                    ),
                    Text(
                      "랭킹",
                      style: theme.textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
              SizedBox(height: 3.v),
              Align(
                alignment: Alignment.centerLeft,
                child: SizedBox(
                  width: 180.h,
                  child: Divider(
                    color: theme.colorScheme.primary,
                  ),
                ),
              ),
              SizedBox(height: 63.v),
              _buildCalendar(context),
              Spacer(),
              SizedBox(height: 21.v),
              CustomElevatedButton(
                text: "기록하기",
                margin: EdgeInsets.only(
                  left: 42.h,
                  right: 45.h,
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: _buildBottomBar(context),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      title: AppbarTitle(
        text: "기록",
        margin: EdgeInsets.only(left: 24.h),
      ),
    );
  }

  /// Section Widget
  Widget _buildCalendar(BuildContext context) {
    return SizedBox(
      height: 221.v,
      width: 272.h,
      child: CalendarDatePicker2(
        config: CalendarDatePicker2Config(
          calendarType: CalendarDatePicker2Type.single,
          firstDate: DateTime(DateTime.now().year - 5),
          lastDate: DateTime(DateTime.now().year + 5),
          firstDayOfWeek: 0,
        ),
        value: selectedDatesFromCalendar1,
        onValueChanged: (dates) {},
      ),
    );
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        Navigator.pushNamed(
            navigatorKey.currentContext!, getCurrentRoute(type));
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.tf:
        return AppRoutes.two3Page;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.two3Page:
        return Two3Page();
      default:
        return DefaultWidget();
    }
  }
}
