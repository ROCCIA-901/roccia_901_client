import 'package:calendar_date_picker2/calendar_date_picker2.dart';
import 'package:flutter/material.dart';
import 'package:newjeans_s_application1/core/app_export.dart';
import 'package:newjeans_s_application1/presentation/two3_page/two3_page.dart';
import 'package:newjeans_s_application1/widgets/app_bar/appbar_title.dart';
import 'package:newjeans_s_application1/widgets/app_bar/custom_app_bar.dart';
import 'package:newjeans_s_application1/widgets/custom_bottom_bar.dart';
import 'package:newjeans_s_application1/widgets/custom_elevated_button.dart';

class K30Screen extends StatelessWidget {
  K30Screen({Key? key})
      : super(
          key: key,
        );

  List<DateTime?> selectedDatesFromCalendar1 = [];

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: _buildAppBar(context),
        body: SizedBox(
          width: double.maxFinite,
          child: Column(
            children: [
              SizedBox(height: 3.v),
              Expanded(
                child: SingleChildScrollView(
                  child: Padding(
                    padding: EdgeInsets.only(bottom: 5.v),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Align(
                          alignment: Alignment.center,
                          child: Padding(
                            padding: EdgeInsets.symmetric(horizontal: 73.h),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  "내 기록",
                                  style: CustomTextStyles.bodySmallBlack900,
                                ),
                                Text(
                                  "랭킹",
                                  style: theme.textTheme.bodySmall,
                                ),
                              ],
                            ),
                          ),
                        ),
                        SizedBox(height: 3.v),
                        SizedBox(
                          width: 180.h,
                          child: Divider(
                            color: theme.colorScheme.primary,
                          ),
                        ),
                        SizedBox(height: 63.v),
                        _buildCalendar(context),
                        SizedBox(height: 24.v),
                        Divider(),
                        SizedBox(height: 30.v),
                        Padding(
                          padding: EdgeInsets.only(
                            left: 46.h,
                            right: 103.h,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                "지점",
                                style:
                                    CustomTextStyles.labelLargeGray600SemiBold,
                              ),
                              Text(
                                "더클라임  연남점",
                                style: CustomTextStyles.bodySmallGray60012,
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 24.v),
                        Padding(
                          padding: EdgeInsets.only(
                            left: 46.h,
                            right: 89.h,
                          ),
                          child: Row(
                            children: [
                              Text(
                                "시간",
                                style:
                                    CustomTextStyles.labelLargeGray600SemiBold,
                              ),
                              Spacer(),
                              Text(
                                "18:30",
                                style: CustomTextStyles.bodySmallGray60012,
                              ),
                              Padding(
                                padding: EdgeInsets.only(left: 13.h),
                                child: Text(
                                  "~",
                                  style: CustomTextStyles.bodySmallGray60012,
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.only(left: 13.h),
                                child: Text(
                                  "21:00",
                                  style: CustomTextStyles.bodySmallGray60012,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 24.v),
                        Padding(
                          padding: EdgeInsets.only(
                            left: 45.h,
                            right: 124.h,
                          ),
                          child: Row(
                            children: [
                              Text(
                                "완등한 문제",
                                style:
                                    CustomTextStyles.labelLargeGray600SemiBold,
                              ),
                              Spacer(),
                              Text(
                                "파랑",
                                style: CustomTextStyles.bodySmallGray60012,
                              ),
                              Padding(
                                padding: EdgeInsets.only(left: 21.h),
                                child: Text(
                                  "3개",
                                  style: CustomTextStyles.bodySmallGray60012,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 14.v),
                        Align(
                          alignment: Alignment.centerRight,
                          child: Padding(
                            padding: EdgeInsets.only(right: 124.h),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Text(
                                  "빨강",
                                  style: CustomTextStyles.bodySmallGray60012,
                                ),
                                Padding(
                                  padding: EdgeInsets.only(left: 22.h),
                                  child: Text(
                                    "1개",
                                    style: CustomTextStyles.bodySmallGray60012,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        SizedBox(height: 49.v),
                        CustomElevatedButton(
                          text: "수정하기",
                          margin: EdgeInsets.only(
                            left: 42.h,
                            right: 45.h,
                          ),
                          alignment: Alignment.center,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: _buildBottomBar(context),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      title: AppbarTitle(
        text: "기록",
        margin: EdgeInsets.only(left: 24.h),
      ),
    );
  }

  /// Section Widget
  Widget _buildCalendar(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: SizedBox(
        height: 221.v,
        width: 272.h,
        child: CalendarDatePicker2(
          config: CalendarDatePicker2Config(
            calendarType: CalendarDatePicker2Type.single,
            firstDate: DateTime(DateTime.now().year - 5),
            lastDate: DateTime(DateTime.now().year + 5),
            firstDayOfWeek: 0,
          ),
          value: selectedDatesFromCalendar1,
          onValueChanged: (dates) {},
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        Navigator.pushNamed(
            navigatorKey.currentContext!, getCurrentRoute(type));
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.tf:
        return AppRoutes.two3Page;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.two3Page:
        return Two3Page();
      default:
        return DefaultWidget();
    }
  }
}
