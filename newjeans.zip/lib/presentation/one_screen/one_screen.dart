import 'package:flutter/material.dart';
import 'package:newjeans_s_application1/core/app_export.dart';

class OneScreen extends StatelessWidget {
  const OneScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: SizedBox(
          width: double.maxFinite,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CustomImageView(
                imagePath: ImageConstant.imgProfile,
                height: 55.v,
                width: 49.h,
              ),
              SizedBox(height: 13.v),
              Text(
                "ROCCIA 901",
                style: theme.textTheme.headlineSmall,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
