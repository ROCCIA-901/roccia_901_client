import '../one14_screen/widgets/registrationgrid_item_widget.dart';import 'package:flutter/material.dart';import 'package:newjeans_s_application1/core/app_export.dart';import 'package:newjeans_s_application1/widgets/app_bar/appbar_leading_image.dart';import 'package:newjeans_s_application1/widgets/app_bar/appbar_title.dart';import 'package:newjeans_s_application1/widgets/app_bar/custom_app_bar.dart';import 'package:newjeans_s_application1/widgets/custom_drop_down.dart';import 'package:newjeans_s_application1/widgets/custom_elevated_button.dart';import 'package:newjeans_s_application1/widgets/custom_text_form_field.dart';
// ignore_for_file: must_be_immutable
class One14Screen extends StatelessWidget {One14Screen({Key? key}) : super(key: key);

TextEditingController loginFormController = TextEditingController();

TextEditingController verificationCodeInputController = TextEditingController();

TextEditingController nameInputController = TextEditingController();

TextEditingController emailInputController = TextEditingController();

TextEditingController passwordInputController = TextEditingController();

List<String> dropdownItemList = ["Item One", "Item Two", "Item Three"];

List<String> dropdownItemList1 = ["Item One", "Item Two", "Item Three"];

List<String> dropdownItemList2 = ["Item One", "Item Two", "Item Three"];

List<String> dropdownItemList3 = ["Item One", "Item Two", "Item Three"];

TextEditingController registrationFormController = TextEditingController();

@override Widget build(BuildContext context) { return SafeArea(child: Scaffold(resizeToAvoidBottomInset: false, appBar: _buildAppBar(context), body: SizedBox(width: double.maxFinite, child: Column(children: [SizedBox(height: 34.v), Expanded(child: SingleChildScrollView(child: Container(margin: EdgeInsets.only(bottom: 5.v), padding: EdgeInsets.symmetric(horizontal: 24.h), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text("이메일", style: CustomTextStyles.bodySmallRobotoBlack900_1), SizedBox(height: 12.v), _buildLoginFormRow1(context), SizedBox(height: 5.v), _buildLoginFormRow2(context), SizedBox(height: 34.v), Text("비밀번호", style: CustomTextStyles.bodySmallRobotoBlack900_1), SizedBox(height: 12.v), _buildNameInput(context), SizedBox(height: 34.v), Text("비밀번호 확인", style: CustomTextStyles.bodySmallRobotoBlack900_1), SizedBox(height: 12.v), _buildEmailInput(context), SizedBox(height: 34.v), Text("이름", style: CustomTextStyles.bodySmallRobotoBlack900_1), SizedBox(height: 12.v), _buildPasswordInput(context), SizedBox(height: 34.v), Text("기수", style: CustomTextStyles.bodySmallRobotoBlack900_1), SizedBox(height: 12.v), CustomDropDown(icon: Container(margin: EdgeInsets.fromLTRB(30.h, 8.v, 3.h, 4.v), child: CustomImageView(imagePath: ImageConstant.imgArrowdown, height: 24.adaptSize, width: 24.adaptSize)), hintText: "본인의 기수를 선택해 주세요.", items: dropdownItemList, onChanged: (value) {}), SizedBox(height: 34.v), Text("역할", style: CustomTextStyles.bodySmallRobotoBlack900_1), SizedBox(height: 12.v), CustomDropDown(icon: Container(margin: EdgeInsets.fromLTRB(30.h, 8.v, 3.h, 4.v), child: CustomImageView(imagePath: ImageConstant.imgArrowdown, height: 24.adaptSize, width: 24.adaptSize)), hintText: "본인의 역할을 선택해 주세요.", items: dropdownItemList1, onChanged: (value) {}), SizedBox(height: 34.v), Text("운동 지점", style: CustomTextStyles.bodySmallRobotoBlack900_1), SizedBox(height: 12.v), CustomDropDown(icon: Container(margin: EdgeInsets.fromLTRB(30.h, 8.v, 3.h, 4.v), child: CustomImageView(imagePath: ImageConstant.imgArrowdown, height: 24.adaptSize, width: 24.adaptSize)), hintText: "본인의 운동 지점을 선택해 주세요.", items: dropdownItemList2, onChanged: (value) {}), SizedBox(height: 34.v), Text("운동 난이도", style: CustomTextStyles.bodySmallRobotoBlack900_1), SizedBox(height: 12.v), CustomDropDown(icon: Container(margin: EdgeInsets.fromLTRB(3.h, 8.v, 3.h, 4.v), child: CustomImageView(imagePath: ImageConstant.imgArrowdown, height: 24.adaptSize, width: 24.adaptSize)), hintText: "본인의 볼더링 난이도를 선택해 주세요.(더클라임 기준)", items: dropdownItemList3, onChanged: (value) {}), SizedBox(height: 31.v), Text("프로필", style: CustomTextStyles.bodySmallRobotoBlack900_1), SizedBox(height: 10.v), Text("프로필로 사용할 이미지를 선택해 주세요.", style: CustomTextStyles.bodySmallRobotoBluegray10001), SizedBox(height: 14.v), _buildRegistrationGrid(context), SizedBox(height: 31.v), Text("소개", style: CustomTextStyles.bodySmallRobotoBlack900_1), SizedBox(height: 12.v), _buildRegistrationForm(context)]))))])), bottomNavigationBar: _buildRegisterButton(context))); } 
/// Section Widget
PreferredSizeWidget _buildAppBar(BuildContext context) { return CustomAppBar(leadingWidth: 42.h, leading: AppbarLeadingImage(imagePath: ImageConstant.imgArrowLeftBlack900, margin: EdgeInsets.only(left: 14.h, top: 13.v, bottom: 13.v), onTap: () {onTapArrowLeft(context);}), title: AppbarTitle(text: "회원가입")); } 
/// Section Widget
Widget _buildLoginForm(BuildContext context) { return CustomTextFormField(width: 202.h, controller: loginFormController, hintText: "이메일을 입력해 주세요."); } 
/// Section Widget
Widget _buildGetVerificationCodeButton(BuildContext context) { return CustomElevatedButton(height: 36.v, width: 97.h, text: "인증번호 받기", buttonStyle: CustomButtonStyles.fillPrimaryTL6, buttonTextStyle: CustomTextStyles.labelLargeRoboto); } 
/// Section Widget
Widget _buildLoginFormRow1(BuildContext context) { return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [_buildLoginForm(context), _buildGetVerificationCodeButton(context)]); } 
/// Section Widget
Widget _buildVerificationCodeInput(BuildContext context) { return CustomTextFormField(width: 202.h, controller: verificationCodeInputController, hintText: "1:00"); } 
/// Section Widget
Widget _buildVerifyCodeButton(BuildContext context) { return CustomElevatedButton(height: 36.v, width: 97.h, text: "인증번호 확인", buttonStyle: CustomButtonStyles.fillPrimaryTL6, buttonTextStyle: CustomTextStyles.labelLargeRoboto); } 
/// Section Widget
Widget _buildLoginFormRow2(BuildContext context) { return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [_buildVerificationCodeInput(context), _buildVerifyCodeButton(context)]); } 
/// Section Widget
Widget _buildNameInput(BuildContext context) { return CustomTextFormField(controller: nameInputController, hintText: "영문, 숫자, 특수문자를 포함하여 7자 이상 입력해 주세요."); } 
/// Section Widget
Widget _buildEmailInput(BuildContext context) { return CustomTextFormField(controller: emailInputController, hintText: "비밀번호를 다시 한번 입력해 주세요."); } 
/// Section Widget
Widget _buildPasswordInput(BuildContext context) { return CustomTextFormField(controller: passwordInputController, hintText: "본인 이름을 입력해 주세요."); } 
/// Section Widget
Widget _buildRegistrationGrid(BuildContext context) { return GridView.builder(shrinkWrap: true, gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(mainAxisExtent: 69.v, crossAxisCount: 4, mainAxisSpacing: 13.h, crossAxisSpacing: 13.h), physics: NeverScrollableScrollPhysics(), itemCount: 8, itemBuilder: (context, index) {return RegistrationgridItemWidget();}); } 
/// Section Widget
Widget _buildRegistrationForm(BuildContext context) { return CustomTextFormField(controller: registrationFormController, hintText: "본인 소개 글을 작성해 주세요.(300자 이하)", hintStyle: CustomTextStyles.bodySmallRobotoBluegray10001_1, textInputAction: TextInputAction.done, maxLines: 12, contentPadding: EdgeInsets.symmetric(horizontal: 14.h, vertical: 13.v)); } 
/// Section Widget
Widget _buildRegisterButton(BuildContext context) { return CustomElevatedButton(text: "가입하기", margin: EdgeInsets.only(left: 24.h, right: 25.h, bottom: 25.v)); } 

/// Navigates back to the previous screen.
onTapArrowLeft(BuildContext context) { Navigator.pop(context); } 
 }
