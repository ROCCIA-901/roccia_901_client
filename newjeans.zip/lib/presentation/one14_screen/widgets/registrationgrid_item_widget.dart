import 'package:flutter/material.dart';
import 'package:newjeans_s_application1/core/app_export.dart';
import 'package:newjeans_s_application1/widgets/custom_icon_button.dart';

// ignore: must_be_immutable
class RegistrationgridItemWidget extends StatelessWidget {
  const RegistrationgridItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 68.adaptSize,
      width: 68.adaptSize,
      padding: EdgeInsets.all(2.h),
      decoration: AppDecoration.outlineGreen.copyWith(
        borderRadius: BorderRadiusStyle.circleBorder34,
      ),
      child: CustomIconButton(
        height: 58.adaptSize,
        width: 58.adaptSize,
        padding: EdgeInsets.all(5.h),
        alignment: Alignment.center,
        child: CustomImageView(
          imagePath: ImageConstant.imgMobile,
        ),
      ),
    );
  }
}
