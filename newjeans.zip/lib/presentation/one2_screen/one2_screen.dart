import 'package:calendar_date_picker2/calendar_date_picker2.dart';
import 'package:flutter/material.dart';
import 'package:newjeans_s_application1/core/app_export.dart';
import 'package:newjeans_s_application1/presentation/two3_page/two3_page.dart';
import 'package:newjeans_s_application1/widgets/app_bar/appbar_title.dart';
import 'package:newjeans_s_application1/widgets/app_bar/custom_app_bar.dart';
import 'package:newjeans_s_application1/widgets/custom_bottom_bar.dart';

class One2Screen extends StatelessWidget {
  One2Screen({Key? key})
      : super(
          key: key,
        );

  List<DateTime?> selectedDatesFromCalendar1 = [];

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: _buildAppBar(context),
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(
            horizontal: 24.h,
            vertical: 12.v,
          ),
          child: Column(
            children: [
              _buildFiftySeven(context),
              SizedBox(height: 24.v),
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  "출석",
                  style: theme.textTheme.bodySmall,
                ),
              ),
              SizedBox(height: 9.v),
              _buildSettingsRow(context),
              SizedBox(height: 24.v),
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  "출석 현황",
                  style: theme.textTheme.bodySmall,
                ),
              ),
              SizedBox(height: 29.v),
              _buildCalendar(context),
            ],
          ),
        ),
        bottomNavigationBar: _buildBottomBar(context),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      height: 53.v,
      title: AppbarTitle(
        text: "홈",
        margin: EdgeInsets.only(left: 24.h),
      ),
    );
  }

  /// Section Widget
  Widget _buildFiftySeven(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 13.h,
        vertical: 15.v,
      ),
      decoration: AppDecoration.fillGray.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder6,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            "앱 사용방법,  공지사항, 동아리 규정이 들어갈 예정입니다.",
            style: CustomTextStyles.labelLargeRobotoBlack900,
          ),
          SizedBox(height: 12.v),
          Text(
            "앱 사용방법, 공지사항, 동아리 규정이 들어갈 예정입니다.",
            style: CustomTextStyles.bodySmallRobotoBlack900,
          ),
          SizedBox(height: 9.v),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildSettingsRow(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Expanded(
          child: Container(
            margin: EdgeInsets.only(right: 6.h),
            padding: EdgeInsets.symmetric(
              horizontal: 58.h,
              vertical: 10.v,
            ),
            decoration: AppDecoration.outlinePrimary.copyWith(
              borderRadius: BorderRadiusStyle.roundedBorder6,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  height: 23.v,
                  width: 22.h,
                  margin: EdgeInsets.only(left: 3.h),
                  padding: EdgeInsets.symmetric(
                    horizontal: 3.h,
                    vertical: 6.v,
                  ),
                  decoration: AppDecoration.fillLightGreen.copyWith(
                    borderRadius: BorderRadiusStyle.roundedBorder11,
                  ),
                  child: CustomImageView(
                    imagePath: ImageConstant.imgSettingsPrimary,
                    height: 11.v,
                    width: 14.h,
                    alignment: Alignment.centerLeft,
                  ),
                ),
                SizedBox(height: 1.v),
                Text(
                  "출석하기",
                  style: CustomTextStyles.bodySmall8,
                ),
              ],
            ),
          ),
        ),
        Expanded(
          child: Container(
            margin: EdgeInsets.only(left: 6.h),
            padding: EdgeInsets.symmetric(
              horizontal: 57.h,
              vertical: 10.v,
            ),
            decoration: AppDecoration.outlinePrimary.copyWith(
              borderRadius: BorderRadiusStyle.roundedBorder6,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  height: 23.v,
                  width: 22.h,
                  padding: EdgeInsets.all(6.h),
                  decoration: AppDecoration.fillLightGreen.copyWith(
                    borderRadius: BorderRadiusStyle.roundedBorder11,
                  ),
                  child: CustomImageView(
                    imagePath: ImageConstant.imgPinterest,
                    height: 11.v,
                    width: 9.h,
                    alignment: Alignment.centerLeft,
                  ),
                ),
                SizedBox(height: 1.v),
                Text(
                  "출석 내역",
                  style: CustomTextStyles.bodySmall8,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  /// Section Widget
  Widget _buildCalendar(BuildContext context) {
    return SizedBox(
      height: 221.v,
      width: 272.h,
      child: CalendarDatePicker2(
        config: CalendarDatePicker2Config(
          calendarType: CalendarDatePicker2Type.single,
          firstDate: DateTime(DateTime.now().year - 5),
          lastDate: DateTime(DateTime.now().year + 5),
          firstDayOfWeek: 0,
        ),
        value: selectedDatesFromCalendar1,
        onValueChanged: (dates) {},
      ),
    );
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        Navigator.pushNamed(
            navigatorKey.currentContext!, getCurrentRoute(type));
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.tf:
        return AppRoutes.two3Page;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.two3Page:
        return Two3Page();
      default:
        return DefaultWidget();
    }
  }
}
