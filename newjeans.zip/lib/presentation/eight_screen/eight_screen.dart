import 'package:flutter/material.dart';
import 'package:newjeans_s_application1/core/app_export.dart';
import 'package:newjeans_s_application1/widgets/custom_elevated_button.dart';
import 'package:newjeans_s_application1/widgets/custom_text_form_field.dart';

class EightScreen extends StatelessWidget {
  EightScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController emailController = TextEditingController();

  TextEditingController passwordController = TextEditingController();

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: SizedBox(
          width: SizeUtils.width,
          child: SingleChildScrollView(
            padding: EdgeInsets.only(
              bottom: MediaQuery.of(context).viewInsets.bottom,
            ),
            child: Form(
              key: _formKey,
              child: Container(
                width: double.maxFinite,
                padding: EdgeInsets.only(
                  left: 24.h,
                  top: 120.v,
                  right: 24.h,
                ),
                child: Column(
                  children: [
                    CustomImageView(
                      imagePath: ImageConstant.imgProfile,
                      height: 55.v,
                      width: 49.h,
                    ),
                    SizedBox(height: 13.v),
                    Text(
                      "ROCCIA 901",
                      style: theme.textTheme.headlineSmall,
                    ),
                    SizedBox(height: 59.v),
                    CustomTextFormField(
                      controller: emailController,
                      hintText: "이메일",
                      hintStyle:
                          CustomTextStyles.bodySmallArchivoBlackBluegray10001,
                      borderDecoration:
                          TextFormFieldStyleHelper.outlineBlueGray,
                      filled: true,
                      fillColor: appTheme.whiteA700,
                    ),
                    SizedBox(height: 5.v),
                    CustomTextFormField(
                      controller: passwordController,
                      hintText: "비밀번호",
                      hintStyle:
                          CustomTextStyles.bodySmallArchivoBlackBluegray10001,
                      textInputAction: TextInputAction.done,
                      textInputType: TextInputType.visiblePassword,
                      obscureText: true,
                      borderDecoration:
                          TextFormFieldStyleHelper.outlineBlueGray,
                      filled: true,
                      fillColor: appTheme.whiteA700,
                    ),
                    SizedBox(height: 15.v),
                    CustomElevatedButton(
                      text: "로그인",
                    ),
                    SizedBox(height: 3.v),
                    Align(
                      alignment: Alignment.centerRight,
                      child: Padding(
                        padding: EdgeInsets.only(right: 2.h),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Text(
                              "회원가입",
                              style: CustomTextStyles
                                  .bodySmallArchivoBlackBluegray10001_1,
                            ),
                            Padding(
                              padding: EdgeInsets.only(left: 6.h),
                              child: Text(
                                "ㅣ",
                                style: CustomTextStyles
                                    .bodySmallArchivoBlackBluegray10001_1,
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.only(left: 5.h),
                              child: Text(
                                "비밀번호 찾기",
                                style: CustomTextStyles
                                    .bodySmallArchivoBlackBluegray10001_1,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 5.v),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
