import 'package:flutter/material.dart';
import 'package:newjeans_s_application1/core/app_export.dart';
import 'package:newjeans_s_application1/widgets/custom_elevated_button.dart';
import 'package:newjeans_s_application1/widgets/custom_text_form_field.dart';

class SixScreen extends StatelessWidget {
  SixScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController dataThreeController = TextEditingController();

  TextEditingController dataFiveController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.only(
            left: 24.h,
            top: 120.v,
            right: 24.h,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CustomImageView(
                imagePath: ImageConstant.imgProfile,
                height: 55.v,
                width: 49.h,
                alignment: Alignment.center,
              ),
              SizedBox(height: 13.v),
              Align(
                alignment: Alignment.center,
                child: Text(
                  "ROCCIA 901",
                  style: theme.textTheme.headlineSmall,
                ),
              ),
              SizedBox(height: 38.v),
              Text(
                "새 비밀번호",
                style: CustomTextStyles.bodySmallRobotoBlack900_1,
              ),
              SizedBox(height: 12.v),
              CustomTextFormField(
                controller: dataThreeController,
                hintText: "영문, 숫자, 특수문자를 포함하여 7자 이상 입력해 주세요.",
              ),
              SizedBox(height: 24.v),
              Text(
                "새 비밀번호 확인",
                style: CustomTextStyles.bodySmallRobotoBlack900_1,
              ),
              SizedBox(height: 12.v),
              CustomTextFormField(
                controller: dataFiveController,
                hintText: "비밀번호를 다시 한번 입력해 주세요.",
                textInputAction: TextInputAction.done,
              ),
              SizedBox(height: 15.v),
              CustomElevatedButton(
                text: "비밀번호 변경하기",
              ),
              SizedBox(height: 3.v),
              Align(
                alignment: Alignment.centerRight,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      "회원가입",
                      style:
                          CustomTextStyles.bodySmallArchivoBlackBluegray10001_1,
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 6.h),
                      child: Text(
                        "ㅣ",
                        style: CustomTextStyles
                            .bodySmallArchivoBlackBluegray10001_1,
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 5.h),
                      child: Text(
                        "로그인",
                        style: CustomTextStyles
                            .bodySmallArchivoBlackBluegray10001_1,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 5.v),
            ],
          ),
        ),
      ),
    );
  }
}
