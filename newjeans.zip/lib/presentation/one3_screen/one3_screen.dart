import 'package:flutter/material.dart';import 'package:newjeans_s_application1/core/app_export.dart';import 'package:newjeans_s_application1/presentation/two3_page/two3_page.dart';import 'package:newjeans_s_application1/widgets/app_bar/appbar_leading_image.dart';import 'package:newjeans_s_application1/widgets/app_bar/appbar_title.dart';import 'package:newjeans_s_application1/widgets/app_bar/custom_app_bar.dart';import 'package:newjeans_s_application1/widgets/custom_bottom_bar.dart';import 'package:newjeans_s_application1/widgets/custom_elevated_button.dart';
// ignore_for_file: must_be_immutable
class One3Screen extends StatelessWidget {One3Screen({Key? key}) : super(key: key);

GlobalKey<NavigatorState> navigatorKey = GlobalKey();

@override Widget build(BuildContext context) { return SafeArea(child: Scaffold(appBar: _buildAppBar(context), body: Container(width: double.maxFinite, padding: EdgeInsets.symmetric(horizontal: 24.h, vertical: 25.v), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [SizedBox(height: 22.v), RichText(text: TextSpan(children: [TextSpan(text: "오늘은 ", style: CustomTextStyles.bodySmallRobotoff000000), TextSpan(text: "양재 지점에서 운동하는 날입니다!", style: CustomTextStyles.labelLargeRobotoff000000)]), textAlign: TextAlign.left), SizedBox(height: 60.v), Text("내 출석률", style: theme.textTheme.bodySmall), SizedBox(height: 14.v), _buildEightyEight(context), Align(alignment: Alignment.centerRight, child: Padding(padding: EdgeInsets.only(right: 54.h), child: Text("80%", style: CustomTextStyles.bodySmall8))), Spacer(), CustomElevatedButton(text: "출석하기", margin: EdgeInsets.only(left: 39.h, right: 40.h), alignment: Alignment.center)])), bottomNavigationBar: _buildBottomBar(context))); } 
/// Section Widget
PreferredSizeWidget _buildAppBar(BuildContext context) { return CustomAppBar(leadingWidth: 42.h, leading: AppbarLeadingImage(imagePath: ImageConstant.imgArrowLeftBlack900, margin: EdgeInsets.only(left: 14.h, top: 13.v, bottom: 13.v), onTap: () {onTapArrowLeft(context);}), title: AppbarTitle(text: "출석하기")); } 
/// Section Widget
Widget _buildEightyEight(BuildContext context) { return Container(width: 312.h, decoration: AppDecoration.fillGray20001.copyWith(borderRadius: BorderRadiusStyle.roundedBorder11), child: Container(height: 25.v, width: 249.h, decoration: BoxDecoration(color: theme.colorScheme.primary, borderRadius: BorderRadius.circular(12.h)))); } 
/// Section Widget
Widget _buildBottomBar(BuildContext context) { return CustomBottomBar(onChanged: (BottomBarEnum type) {Navigator.pushNamed(navigatorKey.currentContext!, getCurrentRoute(type));}); } 
///Handling route based on bottom click actions
String getCurrentRoute(BottomBarEnum type) { switch (type) {case BottomBarEnum.tf: return AppRoutes.two3Page; default: return "/";} } 
///Handling page based on route
Widget getCurrentPage(String currentRoute) { switch (currentRoute) {case AppRoutes.two3Page: return Two3Page(); default: return DefaultWidget();} } 

/// Navigates back to the previous screen.
onTapArrowLeft(BuildContext context) { Navigator.pop(context); } 
 }
