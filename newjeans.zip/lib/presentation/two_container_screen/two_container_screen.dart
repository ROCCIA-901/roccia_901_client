import 'package:flutter/material.dart';import 'package:newjeans_s_application1/core/app_export.dart';import 'package:newjeans_s_application1/presentation/two3_page/two3_page.dart';import 'package:newjeans_s_application1/widgets/custom_bottom_bar.dart';
// ignore_for_file: must_be_immutable
class TwoContainerScreen extends StatelessWidget {TwoContainerScreen({Key? key}) : super(key: key);

GlobalKey<NavigatorState> navigatorKey = GlobalKey();

@override Widget build(BuildContext context) { return SafeArea(child: Scaffold(body: Navigator(key: navigatorKey, initialRoute: AppRoutes.two3Page, onGenerateRoute: (routeSetting) => PageRouteBuilder(pageBuilder: (ctx, ani, ani1) => getCurrentPage(routeSetting.name!), transitionDuration: Duration(seconds: 0))), bottomNavigationBar: _buildBottomBar(context))); } 
/// Section Widget
Widget _buildBottomBar(BuildContext context) { return CustomBottomBar(onChanged: (BottomBarEnum type) {Navigator.pushNamed(navigatorKey.currentContext!, getCurrentRoute(type));}); } 
///Handling route based on bottom click actions
String getCurrentRoute(BottomBarEnum type) { switch (type) {case BottomBarEnum.tf: return AppRoutes.two3Page; default: return "/";} } 
///Handling page based on route
Widget getCurrentPage(String currentRoute) { switch (currentRoute) {case AppRoutes.two3Page: return Two3Page(); default: return DefaultWidget();} } 
 }
