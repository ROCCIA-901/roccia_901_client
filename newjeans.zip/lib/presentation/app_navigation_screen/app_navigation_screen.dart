import 'package:flutter/material.dart';
import 'package:newjeans_s_application1/core/app_export.dart';

class AppNavigationScreen extends StatelessWidget {
  const AppNavigationScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Color(0XFFFFFFFF),
        body: SizedBox(
          width: 375.h,
          child: Column(
            children: [
              _buildAppNavigation(context),
              Expanded(
                child: SingleChildScrollView(
                  child: Container(
                    decoration: BoxDecoration(
                      color: Color(0XFFFFFFFF),
                    ),
                    child: Column(
                      children: [
                        _buildScreenTitle(
                          context,
                          screenTitle: "온보딩 화면 Two",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.twoScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "로그인 화면 Two",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.two1Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "회원가입 화면",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.k2Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "로그인 화면 Seven",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.sevenScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "로그인 화면",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.k4Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "온보딩 화면 One",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.oneScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "로그인 화면 Eight",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.eightScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "회원가입 화면 Two",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.two2Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "로그인 화면 Five",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.fiveScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "로그인 화면 Four",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.fourScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "부원 홈 - 메인 Two - Container",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.twoContainerScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "부원 홈 - 출석하기",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.k12Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "부원 홈 - 출석내역",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.k13Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "운영진 홈 - 메인 One",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.one1Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "운영진 홈 - 출석 확인 Two",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.two4Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "운영진 홈 - 출석 관리 Two",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.two5Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "부원 홈 - 출석내역 Two",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.two6Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "부원 홈 - 메인 One",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.one2Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "부원 홈 - 출석하기 One",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.one3Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "부원 홈 - 출석내역 Five",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.five1Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "운영진 홈 - 메인",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.k21Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "운영진 홈 - 출석 확인 One",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.one4Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "운영진 홈 - 출석 관리",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.k23Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "부원 홈 - 출석내역 One",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.one5Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "내 기록 - 메인 One",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.one6Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "내 기록 - 기록 확인 One",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.one7Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "내 기록 - 메인",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.k28Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "내 기록 - 기록 확인",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.k30Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "랭킹 - 주간",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.k31Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "랭킹 - 전체",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.k32Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "랭킹 - 주간 One",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.one9Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "랭킹 - 전체 One",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.one10Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "대회",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.k35Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "대회 One",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.one11Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "마이페이지",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.k37Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "마이페이지 One",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.one12Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "온보딩 화면",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.k39Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "로그인 화면 One",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.one13Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "회원가입 화면 One",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.one14Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "로그인 화면 Three",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.threeScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "로그인 화면 Six",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.sixScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "부원 홈 - 메인",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.k44Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "부원 홈 - 출석하기 Two",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.two7Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "부원 홈 - 출석내역 Four",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.four1Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "운영진 홈 - 메인 Two",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.two8Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "운영진 홈 - 출석 확인",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.k48Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "운영진 홈 - 출석 관리 One",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.one15Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "부원 홈 - 출석내역 Three",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.three1Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "내 기록 - 메인 Two",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.two9Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "내 기록 - 기록 확인 Two",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.two11Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Android Small - One",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.androidSmallOneScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "랭킹 - 주간 Two",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.two12Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "랭킹 - 월간",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.k56Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "랭킹 - 전체 Two",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.two13Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "대회 Two",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.two14Screen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "마이페이지 Two",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.two15Screen),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildAppNavigation(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Color(0XFFFFFFFF),
      ),
      child: Column(
        children: [
          SizedBox(height: 10.v),
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.h),
              child: Text(
                "App Navigation",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0XFF000000),
                  fontSize: 20.fSize,
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
          ),
          SizedBox(height: 10.v),
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: EdgeInsets.only(left: 20.h),
              child: Text(
                "Check your app's UI from the below demo screens of your app.",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0XFF888888),
                  fontSize: 16.fSize,
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
          ),
          SizedBox(height: 5.v),
          Divider(
            height: 1.v,
            thickness: 1.v,
            color: Color(0XFF000000),
          ),
        ],
      ),
    );
  }

  /// Common widget
  Widget _buildScreenTitle(
    BuildContext context, {
    required String screenTitle,
    Function? onTapScreenTitle,
  }) {
    return GestureDetector(
      onTap: () {
        onTapScreenTitle!.call();
      },
      child: Container(
        decoration: BoxDecoration(
          color: Color(0XFFFFFFFF),
        ),
        child: Column(
          children: [
            SizedBox(height: 10.v),
            Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.h),
                child: Text(
                  screenTitle,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color(0XFF000000),
                    fontSize: 20.fSize,
                    fontFamily: 'Roboto',
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ),
            ),
            SizedBox(height: 10.v),
            SizedBox(height: 5.v),
            Divider(
              height: 1.v,
              thickness: 1.v,
              color: Color(0XFF888888),
            ),
          ],
        ),
      ),
    );
  }

  /// Common click event
  void onTapScreenTitle(
    BuildContext context,
    String routeName,
  ) {
    Navigator.pushNamed(context, routeName);
  }
}
