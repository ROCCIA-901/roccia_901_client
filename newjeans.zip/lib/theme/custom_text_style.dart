import 'package:flutter/material.dart';
import '../core/app_export.dart';

/// A collection of pre-defined text styles for customizing text appearance,
/// categorized by different font families and weights.
/// Additionally, this class includes extensions on [TextStyle] to easily apply specific font families to text.

class CustomTextStyles {
  // Body text style
  static get bodySmall12 => theme.textTheme.bodySmall!.copyWith(
        fontSize: 12.fSize,
      );
  static get bodySmall8 => theme.textTheme.bodySmall!.copyWith(
        fontSize: 8.fSize,
      );
  static get bodySmallArchivoBlackBlack900 =>
      theme.textTheme.bodySmall!.archivoBlack.copyWith(
        color: appTheme.black900,
      );
  static get bodySmallArchivoBlackBluegray10001 =>
      theme.textTheme.bodySmall!.archivoBlack.copyWith(
        color: appTheme.blueGray10001,
        fontSize: 12.fSize,
      );
  static get bodySmallArchivoBlackBluegray10001_1 =>
      theme.textTheme.bodySmall!.archivoBlack.copyWith(
        color: appTheme.blueGray10001,
      );
  static get bodySmallBlack900 => theme.textTheme.bodySmall!.copyWith(
        color: appTheme.black900,
      );
  static get bodySmallBluegray100 => theme.textTheme.bodySmall!.copyWith(
        color: appTheme.blueGray100,
        fontSize: 12.fSize,
      );
  static get bodySmallBluegray10003 => theme.textTheme.bodySmall!.copyWith(
        color: appTheme.blueGray10003,
        fontSize: 12.fSize,
      );
  static get bodySmallGray600 => theme.textTheme.bodySmall!.copyWith(
        color: appTheme.gray600,
      );
  static get bodySmallGray60012 => theme.textTheme.bodySmall!.copyWith(
        color: appTheme.gray600,
        fontSize: 12.fSize,
      );
  static get bodySmallRoboto => theme.textTheme.bodySmall!.roboto.copyWith(
        fontSize: 12.fSize,
      );
  static get bodySmallRobotoBlack900 =>
      theme.textTheme.bodySmall!.roboto.copyWith(
        color: appTheme.black900,
        fontSize: 12.fSize,
      );
  static get bodySmallRobotoBlack900_1 =>
      theme.textTheme.bodySmall!.roboto.copyWith(
        color: appTheme.black900,
      );
  static get bodySmallRobotoBluegray10001 =>
      theme.textTheme.bodySmall!.roboto.copyWith(
        color: appTheme.blueGray10001,
        fontSize: 12.fSize,
      );
  static get bodySmallRobotoBluegray10001_1 =>
      theme.textTheme.bodySmall!.roboto.copyWith(
        color: appTheme.blueGray10001,
      );
  static get bodySmallRobotoBluegray400 =>
      theme.textTheme.bodySmall!.roboto.copyWith(
        color: appTheme.blueGray400,
        fontSize: 8.fSize,
      );
  static get bodySmallRobotoGray600 =>
      theme.textTheme.bodySmall!.roboto.copyWith(
        color: appTheme.gray600,
      );
  static get bodySmallRobotoGray6008 =>
      theme.textTheme.bodySmall!.roboto.copyWith(
        color: appTheme.gray600,
        fontSize: 8.fSize,
      );
  static get bodySmallRobotoff000000 =>
      theme.textTheme.bodySmall!.roboto.copyWith(
        color: Color(0XFF000000),
        fontSize: 12.fSize,
      );
  // Label text style
  static get labelLargeGray600 => theme.textTheme.labelLarge!.copyWith(
        color: appTheme.gray600,
        fontSize: 12.fSize,
        fontWeight: FontWeight.w500,
      );
  static get labelLargeGray600SemiBold => theme.textTheme.labelLarge!.copyWith(
        color: appTheme.gray600,
        fontSize: 12.fSize,
        fontWeight: FontWeight.w600,
      );
  static get labelLargeRoboto => theme.textTheme.labelLarge!.roboto.copyWith(
        fontSize: 12.fSize,
      );
  static get labelLargeRobotoBlack900 =>
      theme.textTheme.labelLarge!.roboto.copyWith(
        color: appTheme.black900,
        fontSize: 12.fSize,
        fontWeight: FontWeight.w600,
      );
  static get labelLargeRobotoff000000 =>
      theme.textTheme.labelLarge!.roboto.copyWith(
        color: Color(0XFF000000),
        fontSize: 12.fSize,
      );
  static get labelSmallPrimary => theme.textTheme.labelSmall!.copyWith(
        color: theme.colorScheme.primary,
        fontWeight: FontWeight.w700,
      );
  static get labelSmallRed300 => theme.textTheme.labelSmall!.copyWith(
        color: appTheme.red300,
        fontWeight: FontWeight.w700,
      );
  static get labelSmallYellowA400 => theme.textTheme.labelSmall!.copyWith(
        color: appTheme.yellowA400,
        fontWeight: FontWeight.w700,
      );
}

extension on TextStyle {
  TextStyle get archivoBlack {
    return copyWith(
      fontFamily: 'Archivo Black',
    );
  }

  TextStyle get roboto {
    return copyWith(
      fontFamily: 'Roboto',
    );
  }

  TextStyle get inter {
    return copyWith(
      fontFamily: 'Inter',
    );
  }
}
