import 'package:flutter/material.dart';
import 'package:newjeans_s_application1/presentation/two_screen/two_screen.dart';
import 'package:newjeans_s_application1/presentation/two1_screen/two1_screen.dart';
import 'package:newjeans_s_application1/presentation/k2_screen/k2_screen.dart';
import 'package:newjeans_s_application1/presentation/seven_screen/seven_screen.dart';
import 'package:newjeans_s_application1/presentation/k4_screen/k4_screen.dart';
import 'package:newjeans_s_application1/presentation/one_screen/one_screen.dart';
import 'package:newjeans_s_application1/presentation/eight_screen/eight_screen.dart';
import 'package:newjeans_s_application1/presentation/two2_screen/two2_screen.dart';
import 'package:newjeans_s_application1/presentation/five_screen/five_screen.dart';
import 'package:newjeans_s_application1/presentation/four_screen/four_screen.dart';
import 'package:newjeans_s_application1/presentation/two_container_screen/two_container_screen.dart';
import 'package:newjeans_s_application1/presentation/k12_screen/k12_screen.dart';
import 'package:newjeans_s_application1/presentation/k13_screen/k13_screen.dart';
import 'package:newjeans_s_application1/presentation/one1_screen/one1_screen.dart';
import 'package:newjeans_s_application1/presentation/two4_screen/two4_screen.dart';
import 'package:newjeans_s_application1/presentation/two5_screen/two5_screen.dart';
import 'package:newjeans_s_application1/presentation/two6_screen/two6_screen.dart';
import 'package:newjeans_s_application1/presentation/one2_screen/one2_screen.dart';
import 'package:newjeans_s_application1/presentation/one3_screen/one3_screen.dart';
import 'package:newjeans_s_application1/presentation/five1_screen/five1_screen.dart';
import 'package:newjeans_s_application1/presentation/k21_screen/k21_screen.dart';
import 'package:newjeans_s_application1/presentation/one4_screen/one4_screen.dart';
import 'package:newjeans_s_application1/presentation/k23_screen/k23_screen.dart';
import 'package:newjeans_s_application1/presentation/one5_screen/one5_screen.dart';
import 'package:newjeans_s_application1/presentation/one6_screen/one6_screen.dart';
import 'package:newjeans_s_application1/presentation/one7_screen/one7_screen.dart';
import 'package:newjeans_s_application1/presentation/k28_screen/k28_screen.dart';
import 'package:newjeans_s_application1/presentation/k30_screen/k30_screen.dart';
import 'package:newjeans_s_application1/presentation/k31_screen/k31_screen.dart';
import 'package:newjeans_s_application1/presentation/k32_screen/k32_screen.dart';
import 'package:newjeans_s_application1/presentation/one9_screen/one9_screen.dart';
import 'package:newjeans_s_application1/presentation/one10_screen/one10_screen.dart';
import 'package:newjeans_s_application1/presentation/k35_screen/k35_screen.dart';
import 'package:newjeans_s_application1/presentation/one11_screen/one11_screen.dart';
import 'package:newjeans_s_application1/presentation/k37_screen/k37_screen.dart';
import 'package:newjeans_s_application1/presentation/one12_screen/one12_screen.dart';
import 'package:newjeans_s_application1/presentation/k39_screen/k39_screen.dart';
import 'package:newjeans_s_application1/presentation/one13_screen/one13_screen.dart';
import 'package:newjeans_s_application1/presentation/one14_screen/one14_screen.dart';
import 'package:newjeans_s_application1/presentation/three_screen/three_screen.dart';
import 'package:newjeans_s_application1/presentation/six_screen/six_screen.dart';
import 'package:newjeans_s_application1/presentation/k44_screen/k44_screen.dart';
import 'package:newjeans_s_application1/presentation/two7_screen/two7_screen.dart';
import 'package:newjeans_s_application1/presentation/four1_screen/four1_screen.dart';
import 'package:newjeans_s_application1/presentation/two8_screen/two8_screen.dart';
import 'package:newjeans_s_application1/presentation/k48_screen/k48_screen.dart';
import 'package:newjeans_s_application1/presentation/one15_screen/one15_screen.dart';
import 'package:newjeans_s_application1/presentation/three1_screen/three1_screen.dart';
import 'package:newjeans_s_application1/presentation/two9_screen/two9_screen.dart';
import 'package:newjeans_s_application1/presentation/two11_screen/two11_screen.dart';
import 'package:newjeans_s_application1/presentation/android_small_one_screen/android_small_one_screen.dart';
import 'package:newjeans_s_application1/presentation/two12_screen/two12_screen.dart';
import 'package:newjeans_s_application1/presentation/k56_screen/k56_screen.dart';
import 'package:newjeans_s_application1/presentation/two13_screen/two13_screen.dart';
import 'package:newjeans_s_application1/presentation/two14_screen/two14_screen.dart';
import 'package:newjeans_s_application1/presentation/two15_screen/two15_screen.dart';
import 'package:newjeans_s_application1/presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String twoScreen = '/two_screen';

  static const String two1Screen = '/two1_screen';

  static const String k2Screen = '/k2_screen';

  static const String sevenScreen = '/seven_screen';

  static const String k4Screen = '/k4_screen';

  static const String oneScreen = '/one_screen';

  static const String eightScreen = '/eight_screen';

  static const String two2Screen = '/two2_screen';

  static const String fiveScreen = '/five_screen';

  static const String fourScreen = '/four_screen';

  static const String two3Page = '/two3_page';

  static const String twoContainerScreen = '/two_container_screen';

  static const String k12Screen = '/k12_screen';

  static const String k13Screen = '/k13_screen';

  static const String one1Screen = '/one1_screen';

  static const String two4Screen = '/two4_screen';

  static const String two5Screen = '/two5_screen';

  static const String two6Screen = '/two6_screen';

  static const String one2Screen = '/one2_screen';

  static const String one3Screen = '/one3_screen';

  static const String five1Screen = '/five1_screen';

  static const String k21Screen = '/k21_screen';

  static const String one4Screen = '/one4_screen';

  static const String k23Screen = '/k23_screen';

  static const String one5Screen = '/one5_screen';

  static const String one6Screen = '/one6_screen';

  static const String one7Screen = '/one7_screen';

  static const String k28Screen = '/k28_screen';

  static const String k30Screen = '/k30_screen';

  static const String k31Screen = '/k31_screen';

  static const String k32Screen = '/k32_screen';

  static const String one9Screen = '/one9_screen';

  static const String one10Screen = '/one10_screen';

  static const String k35Screen = '/k35_screen';

  static const String one11Screen = '/one11_screen';

  static const String k37Screen = '/k37_screen';

  static const String one12Screen = '/one12_screen';

  static const String k39Screen = '/k39_screen';

  static const String one13Screen = '/one13_screen';

  static const String one14Screen = '/one14_screen';

  static const String threeScreen = '/three_screen';

  static const String sixScreen = '/six_screen';

  static const String k44Screen = '/k44_screen';

  static const String two7Screen = '/two7_screen';

  static const String four1Screen = '/four1_screen';

  static const String two8Screen = '/two8_screen';

  static const String k48Screen = '/k48_screen';

  static const String one15Screen = '/one15_screen';

  static const String three1Screen = '/three1_screen';

  static const String two9Screen = '/two9_screen';

  static const String two11Screen = '/two11_screen';

  static const String androidSmallOneScreen = '/android_small_one_screen';

  static const String two12Screen = '/two12_screen';

  static const String k56Screen = '/k56_screen';

  static const String two13Screen = '/two13_screen';

  static const String two14Screen = '/two14_screen';

  static const String two15Screen = '/two15_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static Map<String, WidgetBuilder> routes = {
    twoScreen: (context) => TwoScreen(),
    two1Screen: (context) => Two1Screen(),
    k2Screen: (context) => K2Screen(),
    sevenScreen: (context) => SevenScreen(),
    k4Screen: (context) => K4Screen(),
    oneScreen: (context) => OneScreen(),
    eightScreen: (context) => EightScreen(),
    two2Screen: (context) => Two2Screen(),
    fiveScreen: (context) => FiveScreen(),
    fourScreen: (context) => FourScreen(),
    twoContainerScreen: (context) => TwoContainerScreen(),
    k12Screen: (context) => K12Screen(),
    k13Screen: (context) => K13Screen(),
    one1Screen: (context) => One1Screen(),
    two4Screen: (context) => Two4Screen(),
    two5Screen: (context) => Two5Screen(),
    two6Screen: (context) => Two6Screen(),
    one2Screen: (context) => One2Screen(),
    one3Screen: (context) => One3Screen(),
    five1Screen: (context) => Five1Screen(),
    k21Screen: (context) => K21Screen(),
    one4Screen: (context) => One4Screen(),
    k23Screen: (context) => K23Screen(),
    one5Screen: (context) => One5Screen(),
    one6Screen: (context) => One6Screen(),
    one7Screen: (context) => One7Screen(),
    k28Screen: (context) => K28Screen(),
    k30Screen: (context) => K30Screen(),
    k31Screen: (context) => K31Screen(),
    k32Screen: (context) => K32Screen(),
    one9Screen: (context) => One9Screen(),
    one10Screen: (context) => One10Screen(),
    k35Screen: (context) => K35Screen(),
    one11Screen: (context) => One11Screen(),
    k37Screen: (context) => K37Screen(),
    one12Screen: (context) => One12Screen(),
    k39Screen: (context) => K39Screen(),
    one13Screen: (context) => One13Screen(),
    one14Screen: (context) => One14Screen(),
    threeScreen: (context) => ThreeScreen(),
    sixScreen: (context) => SixScreen(),
    k44Screen: (context) => K44Screen(),
    two7Screen: (context) => Two7Screen(),
    four1Screen: (context) => Four1Screen(),
    two8Screen: (context) => Two8Screen(),
    k48Screen: (context) => K48Screen(),
    one15Screen: (context) => One15Screen(),
    three1Screen: (context) => Three1Screen(),
    two9Screen: (context) => Two9Screen(),
    two11Screen: (context) => Two11Screen(),
    androidSmallOneScreen: (context) => AndroidSmallOneScreen(),
    two12Screen: (context) => Two12Screen(),
    k56Screen: (context) => K56Screen(),
    two13Screen: (context) => Two13Screen(),
    two14Screen: (context) => Two14Screen(),
    two15Screen: (context) => Two15Screen(),
    appNavigationScreen: (context) => AppNavigationScreen()
  };
}
